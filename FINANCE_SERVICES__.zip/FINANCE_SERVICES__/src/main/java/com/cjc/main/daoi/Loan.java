package com.cjc.main.daoi;

import org.springframework.data.repository.CrudRepository;

public interface Loan extends CrudRepository<com.cjc.main.model.Loan, Integer> {

}
