package com.cjc.main.daoi;

import org.springframework.data.repository.CrudRepository;

import com.cjc.main.model.Employee;

public interface Employeedaoi extends CrudRepository<Employee, Integer>{

}
