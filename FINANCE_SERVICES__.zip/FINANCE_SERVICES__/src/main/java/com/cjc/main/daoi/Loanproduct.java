package com.cjc.main.daoi;

import org.springframework.data.repository.CrudRepository;

public interface Loanproduct extends CrudRepository<com.cjc.main.model.Loanproduct, Integer> {

}
